function initializeDetailsPage() {
    if (window.GadgetHub && window.GadgetHub.handleDetailsPage) {
        window.GadgetHub.handleDetailsPage();
        return;
    }

    window.addEventListener('DOMContentLoaded', () => {
        if (window.GadgetHub && window.GadgetHub.handleDetailsPage) {
            window.GadgetHub.handleDetailsPage();
        }
    });
}

initializeDetailsPage();