function initializeCheckoutPage() {
    if (window.GadgetHub && window.GadgetHub.handleCheckoutPage) {
        window.GadgetHub.handleCheckoutPage();
        return;
    }

    window.addEventListener('DOMContentLoaded', () => {
        if (window.GadgetHub && window.GadgetHub.handleCheckoutPage) {
            window.GadgetHub.handleCheckoutPage();
        }
    });
}

initializeCheckoutPage();