function initializeReceiptPage() {
    if (window.GadgetHub && window.GadgetHub.handleReceiptPage) {
        window.GadgetHub.handleReceiptPage();
        return;
    }

    window.addEventListener('DOMContentLoaded', () => {
        if (window.GadgetHub && window.GadgetHub.handleReceiptPage) {
            window.GadgetHub.handleReceiptPage();
        }
    });
}

initializeReceiptPage();