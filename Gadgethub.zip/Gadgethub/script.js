(function () {
    const STORAGE_KEYS = {
        products: 'gadgethub_products',
        users: 'gadgethub_users',
        cart: 'gadgethub_cart',
        orders: 'gadgethub_orders',
        currentUser: 'gadgethub_currentUser',
        selectedProduct: 'gadgethub_selectedProduct',
        categoryFilter: 'gadgethub_categoryFilter',
        latestOrder: 'gadgethub_latestOrder',
        theme: 'gadgethub_theme'
    };

    const DEFAULT_PRODUCTS = [
        { id: 1, name: 'iPhone 16 Pro', price: 129999, category: 'Mobile', image: 'GadgetHub/images/iphone.jpg', description: 'Premium flagship smartphone with advanced camera setup and A18 chip.' },
        { id: 2, name: 'Samsung Galaxy S25', price: 89999, category: 'Mobile', image: 'GadgetHub/images/Samsung.jpg', description: 'Flagship Android experience with AI-powered photography.' },
        { id: 3, name: 'MacBook Air M4', price: 99999, category: 'Laptop', image: 'GadgetHub/images/macbook.jpg', description: 'Lightweight laptop designed for work, creativity and everyday productivity.' },
        { id: 4, name: 'Sony Alpha Camera', price: 74999, category: 'Camera', image: 'GadgetHub/images/sony camera.jpg', description: 'Capture sharp photos with professional-grade image quality.' },
        { id: 5, name: 'OnePlus 12', price: 64999, category: 'Mobile', image: 'GadgetHub/images/oneplus.jpeg', description: 'Fast performance with a smooth AMOLED display.' },
        { id: 6, name: 'Realme GT Neo 6', price: 39999, category: 'Mobile', image: 'GadgetHub/images/realme.jpeg', description: 'High-performance device value for everyday gaming and multitasking.' },
        { id: 7, name: 'Dell XPS 15', price: 119999, category: 'Laptop', image: 'GadgetHub/images/dell.jpeg', description: 'Powerful creator laptop with beautiful display and premium build.' },
        { id: 8, name: 'HP Pavilion 14', price: 69999, category: 'Laptop', image: 'GadgetHub/images/hp.jpeg', description: 'Balanced laptop for office use, study, and entertainment.' },
        { id: 9, name: 'Apple Watch Series 10', price: 45999, category: 'Smartwatch', image: 'GadgetHub/images/applewatch.jpeg', description: 'Stay connected and track health with a premium smartwatch.' },
        { id: 10, name: 'Samsung Galaxy Watch 6', price: 24999, category: 'Smartwatch', image: 'GadgetHub/images/samsungwatch.jpeg', description: 'Reliable fitness insights and stylish smart features.' },
        { id: 11, name: 'Sony WH-1000XM5', price: 29999, category: 'Headphones', image: 'GadgetHub/images/headphones.jpeg', description: 'Noise-cancelling headphones with rich studio-quality sound.' },
        { id: 12, name: 'Boat Airdopes 441', price: 2999, category: 'Earbuds', image: 'GadgetHub/images/boat.jpeg', description: 'Affordable wireless earbuds with strong battery life.' },
        { id: 13, name: 'iPad Pro M2', price: 109999, category: 'Tablet', image: 'GadgetHub/images/ipad.jpeg', description: 'Powerful tablet for professionals, students and creators.' },
        { id: 14, name: 'Lenovo Legion 5', price: 104999, category: 'Laptop', image: 'GadgetHub/images/lenovo.jpeg', description: 'Gaming laptop with strong graphics and responsive performance.' }
    ];

    const DEFAULT_USERS = [
        { id: 1, name: 'Admin', email: 'admin@gadgethub.com', password: 'admin123', role: 'admin' }
    ];

    function safeParse(key, fallback) {
        try {
            const value = localStorage.getItem(key);
            if (!value) return fallback;
            const parsed = JSON.parse(value);
            return parsed;
        } catch (error) {
            console.warn('Store parse failed:', key, error);
            return fallback;
        }
    }

    function ensureStorageReady() {
        if (!localStorage.getItem(STORAGE_KEYS.products)) {
            localStorage.setItem(STORAGE_KEYS.products, JSON.stringify(DEFAULT_PRODUCTS));
        }
        if (!localStorage.getItem(STORAGE_KEYS.users)) {
            localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(DEFAULT_USERS));
        }
        if (!localStorage.getItem(STORAGE_KEYS.cart)) {
            localStorage.setItem(STORAGE_KEYS.cart, JSON.stringify([]));
        }
        if (!localStorage.getItem(STORAGE_KEYS.orders)) {
            localStorage.setItem(STORAGE_KEYS.orders, JSON.stringify([]));
        }
        if (!localStorage.getItem('productsData')) {
            localStorage.setItem('productsData', JSON.stringify(getProducts()));
        }
        if (!localStorage.getItem('order')) {
            localStorage.setItem('order', JSON.stringify(null));
        }
    }

    function getProducts() {
        const products = safeParse(STORAGE_KEYS.products, DEFAULT_PRODUCTS);
        return Array.isArray(products) ? products : DEFAULT_PRODUCTS;
    }

    function saveProducts(products) {
        const payload = Array.isArray(products) ? products : [];
        localStorage.setItem(STORAGE_KEYS.products, JSON.stringify(payload));
        localStorage.setItem('productsData', JSON.stringify(payload));
        return payload;
    }

    function getUsers() {
        const users = safeParse(STORAGE_KEYS.users, DEFAULT_USERS);
        return Array.isArray(users) ? users : DEFAULT_USERS;
    }

    function saveUsers(users) {
        const payload = Array.isArray(users) ? users : [];
        localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(payload));
        return payload;
    }

    function getCart() {
        const cart = safeParse(STORAGE_KEYS.cart, []);
        return Array.isArray(cart) ? cart : [];
    }

    function saveCart(cart) {
        const payload = Array.isArray(cart) ? cart : [];
        localStorage.setItem(STORAGE_KEYS.cart, JSON.stringify(payload));
        return payload;
    }

    function getOrders() {
        const orders = safeParse(STORAGE_KEYS.orders, []);
        return Array.isArray(orders) ? orders : [];
    }

    function saveOrders(orders) {
        const payload = Array.isArray(orders) ? orders : [];
        localStorage.setItem(STORAGE_KEYS.orders, JSON.stringify(payload));
        return payload;
    }

    function getCurrentUser() {
        return safeParse(STORAGE_KEYS.currentUser, null);
    }

    function setCurrentUser(user) {
        if (!user) {
            localStorage.removeItem(STORAGE_KEYS.currentUser);
            return null;
        }
        localStorage.setItem(STORAGE_KEYS.currentUser, JSON.stringify(user));
        return user;
    }

    function logoutUser() {
        setCurrentUser(null);
        return true;
    }

    function getSelectedProductId() {
        return localStorage.getItem(STORAGE_KEYS.selectedProduct);
    }

    function setSelectedProductId(id) {
        localStorage.setItem(STORAGE_KEYS.selectedProduct, id);
    }

    function getLatestOrder() {
        return safeParse(STORAGE_KEYS.latestOrder, null);
    }

    function setLatestOrder(order) {
        localStorage.setItem(STORAGE_KEYS.latestOrder, JSON.stringify(order));
        localStorage.setItem('order', JSON.stringify(order));
    }

    function formatCurrency(value) {
        const numericValue = Number(value) || 0;
        return `₹${numericValue.toLocaleString('en-IN')}`;
    }

    function registerUser(payload) {
        const users = getUsers();
        const normalizedEmail = payload.email.trim().toLowerCase();
        const existingUser = users.find((user) => user.email.toLowerCase() === normalizedEmail);

        if (existingUser) {
            return { ok: false, message: 'An account with this email already exists.' };
        }

        const user = {
            id: Date.now(),
            name: payload.name.trim(),
            email: normalizedEmail,
            password: payload.password,
            role: 'customer'
        };

        users.push(user);
        saveUsers(users);
        setCurrentUser(user);
        return { ok: true, user, message: 'Account created successfully. Welcome to GadgetHub.' };
    }

    function loginUser(email, password) {
        const normalizedEmail = email.trim().toLowerCase();
        const users = getUsers();
        const user = users.find((entry) => entry.email.toLowerCase() === normalizedEmail && entry.password === password);

        if (!user) {
            return { ok: false, message: 'Invalid email or password.' };
        }

        setCurrentUser(user);
        return { ok: true, user, message: `Welcome back, ${user.name}.` };
    }

    function addProduct(product) {
        const products = getProducts();
        const nextProduct = {
            id: Date.now(),
            name: String(product.name || '').trim(),
            price: Number(product.price) || 0,
            category: String(product.category || '').trim(),
            image: String(product.image || '').trim() || 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80',
            description: String(product.description || '').trim() || 'Newly added product available now.'
        };

        products.unshift(nextProduct);
        saveProducts(products);
        return nextProduct;
    }

    function createOrder(orderData) {
        const cart = Array.isArray(orderData.products) ? orderData.products : getCart();
        const total = cart.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
        const order = {
            id: `GH${Math.floor(100000 + Math.random() * 900000)}`,
            userId: orderData.userId || null,
            userName: orderData.userName || 'Guest',
            email: orderData.email || '',
            phone: orderData.phone || '',
            address: orderData.address || '',
            paymentMethod: orderData.paymentMethod || 'Cash on Delivery',
            products: cart,
            total,
            status: 'Pending',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        const orders = getOrders();
        orders.unshift(order);
        saveOrders(orders);
        saveCart([]);
        setLatestOrder(order);
        return order;
    }

    function updateOrderStatus(orderId, status) {
        const orders = getOrders();
        const normalizedStatus = status || 'Pending';
        const updatedOrders = orders.map((order) => {
            if (order.id === orderId) {
                return { ...order, status: normalizedStatus, updatedAt: new Date().toISOString() };
            }
            return order;
        });
        saveOrders(updatedOrders);
        return updatedOrders;
    }

    function viewDetails(id) {
        setSelectedProductId(id);
        window.location.href = 'product-details.html';
    }

    function addToCart(id) {
        const products = getProducts();
        const product = products.find((entry) => Number(entry.id) === Number(id));
        if (!product) {
            alert('Product not found.');
            return;
        }

        const cart = getCart();
        cart.push(product);
        saveCart(cart);
        alert('Added to Cart 🛒');
    }

    function removeCartItem(index) {
        const cart = getCart();
        cart.splice(index, 1);
        saveCart(cart);
        return cart;
    }

    function displayProducts(list, container) {
        if (!container) return;

        container.innerHTML = '';

        if (!list.length) {
            container.innerHTML = '<div class="empty-state">No products match your current filters.</div>';
            return;
        }

        list.forEach((product) => {
            const image = product.image || 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80';
            container.innerHTML += `
                <div class="product-card">
                    <img src="${encodeURI(image)}" alt="${product.name}" />
                    <h3>${product.name}</h3>
                    <p>${product.category}</p>
                    <p>${product.description || ''}</p>
                    <p><strong>${formatCurrency(product.price)}</strong></p>
                    <button onclick="window.GadgetHub.viewDetails(${product.id})">View Details</button>
                    <button onclick="window.GadgetHub.addToCart(${product.id})">Add To Cart 🛒</button>
                </div>
            `;
        });
    }

    function populateCategories(selectEl) {
        if (!selectEl) return;
        const categories = ['All', ...new Set(getProducts().map((product) => product.category))];
        selectEl.innerHTML = '';
        categories.forEach((category) => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            selectEl.appendChild(option);
        });
    }

    function filterAndDisplay() {
        const container = document.getElementById('productContainer');
        const searchInput = document.getElementById('searchInput');
        const sortSelect = document.getElementById('sortSelect');
        const categorySelect = document.getElementById('categorySelect');
        if (!container) return;

        let list = [...getProducts()];
        const category = categorySelect ? categorySelect.value : 'All';
        if (category && category !== 'All') {
            list = list.filter((product) => product.category === category);
        }

        const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
        if (query) {
            list = list.filter((product) => product.name.toLowerCase().includes(query));
        }

        if (sortSelect) {
            if (sortSelect.value === 'low') {
                list.sort((a, b) => Number(a.price) - Number(b.price));
            }
            if (sortSelect.value === 'high') {
                list.sort((a, b) => Number(b.price) - Number(a.price));
            }
        }

        displayProducts(list, container);
    }

    function applyTheme(theme) {
        document.body.classList.toggle('dark', theme === 'dark');
        const themeBtn = document.getElementById('themeBtn');
        if (themeBtn) {
            themeBtn.textContent = theme === 'dark' ? '☀️' : '🌙';
        }
    }

    function initTheme() {
        const savedTheme = localStorage.getItem(STORAGE_KEYS.theme) || 'light';
        applyTheme(savedTheme);

        const themeBtn = document.getElementById('themeBtn');
        if (themeBtn) {
            themeBtn.addEventListener('click', () => {
                const nextTheme = document.body.classList.contains('dark') ? 'light' : 'dark';
                localStorage.setItem(STORAGE_KEYS.theme, nextTheme);
                applyTheme(nextTheme);
            });
        }
    }

    function injectNavigation() {
        const navList = document.querySelector('nav ul');
        if (!navList) return;

        if (!document.getElementById('authNavItem')) {
            const authItem = document.createElement('li');
            authItem.id = 'authNavItem';
            authItem.innerHTML = '<a id="authLink" href="auth.html">Login / Register</a>';
            navList.appendChild(authItem);
        }

        if (!document.getElementById('ordersNavItem')) {
            const ordersItem = document.createElement('li');
            ordersItem.id = 'ordersNavItem';
            ordersItem.innerHTML = '<a href="orders.html">Orders</a>';
            navList.appendChild(ordersItem);
        }

        if (!document.getElementById('logoutNavItem')) {
            const logoutItem = document.createElement('li');
            logoutItem.id = 'logoutNavItem';
            logoutItem.innerHTML = '<a id="logoutLink" href="#">Logout</a>';
            navList.appendChild(logoutItem);
        }

        if (!document.getElementById('adminNavItem')) {
            const adminItem = document.createElement('li');
            adminItem.id = 'adminNavItem';
            adminItem.innerHTML = '<a href="admin.html">Admin</a>';
            navList.appendChild(adminItem);
        }
    }

    function renderAuthState() {
        const currentUser = getCurrentUser();
        const authLink = document.getElementById('authLink');
        const logoutLink = document.getElementById('logoutLink');
        const adminLink = document.querySelector('#adminNavItem a');
        const logoutNavItem = document.getElementById('logoutNavItem');

        if (authLink) {
            if (currentUser) {
                authLink.textContent = `Hi, ${currentUser.name}`;
                authLink.href = 'orders.html';
            } else {
                authLink.textContent = 'Login / Register';
                authLink.href = 'auth.html';
            }
        }

        if (logoutLink) {
            logoutLink.style.display = currentUser ? 'inline-block' : 'none';
            logoutLink.addEventListener('click', (event) => {
                event.preventDefault();
                logoutUser();
                renderAuthState();
                window.location.href = 'index.html';
            });
        }

        if (logoutNavItem) {
            logoutNavItem.style.display = currentUser ? 'list-item' : 'none';
        }

        if (adminLink) {
            adminLink.style.display = currentUser && currentUser.role === 'admin' ? 'inline-block' : 'none';
        }
    }

    function handleProductsPage() {
        const container = document.getElementById('productContainer');
        const searchInput = document.getElementById('searchInput');
        const sortSelect = document.getElementById('sortSelect');
        const categorySelect = document.getElementById('categorySelect');
        if (!container) return;

        populateCategories(categorySelect);
        const savedCategory = localStorage.getItem(STORAGE_KEYS.categoryFilter);
        if (savedCategory && categorySelect) {
            categorySelect.value = savedCategory;
        }

        displayProducts(getProducts(), container);

        if (searchInput) {
            searchInput.addEventListener('keyup', filterAndDisplay);
        }
        if (sortSelect) {
            sortSelect.addEventListener('change', filterAndDisplay);
        }
        if (categorySelect) {
            categorySelect.addEventListener('change', filterAndDisplay);
        }
    }

    function handleHomePage() {
        document.querySelectorAll('.category-card').forEach((card) => {
            const category = card.dataset.category;
            if (!category) return;
            card.style.cursor = 'pointer';
            card.addEventListener('click', () => {
                localStorage.setItem(STORAGE_KEYS.categoryFilter, category);
                window.location.href = 'products.html';
            });
        });
    }

    function handleAuthPage() {
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');
        const authMessage = document.getElementById('authMessage');

        if (loginForm) {
            loginForm.addEventListener('submit', (event) => {
                event.preventDefault();
                const result = loginUser(loginForm.email.value, loginForm.password.value);
                if (authMessage) {
                    authMessage.textContent = result.message;
                }
                if (result.ok) {
                    window.location.href = 'orders.html';
                }
            });
        }

        if (registerForm) {
            registerForm.addEventListener('submit', (event) => {
                event.preventDefault();
                const result = registerUser({
                    name: registerForm.name.value,
                    email: registerForm.email.value,
                    password: registerForm.password.value
                });
                if (authMessage) {
                    authMessage.textContent = result.message;
                }
                if (result.ok) {
                    window.location.href = 'orders.html';
                }
            });
        }
    }

    function handleOrdersPage() {
        const container = document.getElementById('ordersContainer');
        if (!container) return;

        const currentUser = getCurrentUser();
        if (!currentUser) {
            container.innerHTML = '<div class="empty-state">Please log in to view your orders.</div>';
            return;
        }

        const userOrders = currentUser.role === 'admin'
            ? getOrders()
            : getOrders().filter((order) => order.userId === currentUser.id || order.email === currentUser.email);

        if (!userOrders.length) {
            container.innerHTML = '<div class="empty-state">No orders yet. Place your first order to see it here.</div>';
            return;
        }

        container.innerHTML = userOrders.map((order) => {
            const statusLabel = order.status || 'Pending';
            const statusMarkup = currentUser.role === 'admin'
                ? `<select class="status-select" data-order-id="${order.id}">
                    <option value="Pending" ${statusLabel === 'Pending' ? 'selected' : ''}>Pending</option>
                    <option value="Packed" ${statusLabel === 'Packed' ? 'selected' : ''}>Packed</option>
                    <option value="Shipped" ${statusLabel === 'Shipped' ? 'selected' : ''}>Shipped</option>
                    <option value="Delivered" ${statusLabel === 'Delivered' ? 'selected' : ''}>Delivered</option>
                </select>`
                : `<span class="status-badge status-${statusLabel.toLowerCase()}">${statusLabel}</span>`;

            const itemSummary = order.products.map((item) => item.name).join(', ');
            return `
                <div class="order-card">
                    <div class="order-header">
                        <strong>${order.id}</strong>
                        <span>${new Date(order.createdAt).toLocaleString()}</span>
                    </div>
                    <p><strong>Status:</strong> ${statusMarkup}</p>
                    <p><strong>Customer:</strong> ${order.userName || order.userName || 'Guest'}</p>
                    <p><strong>Items:</strong> ${itemSummary}</p>
                    <p><strong>Total:</strong> ${formatCurrency(order.total || 0)}</p>
                </div>
            `;
        }).join('');

        if (currentUser.role === 'admin') {
            document.querySelectorAll('.status-select').forEach((select) => {
                select.addEventListener('change', (event) => {
                    const orderId = event.target.dataset.orderId;
                    updateOrderStatus(orderId, event.target.value);
                    handleOrdersPage();
                });
            });
        }
    }

    function handleAdminPage() {
        const form = document.getElementById('addProductForm');
        const productList = document.getElementById('adminProductList');
        if (!form && !productList) return;

        const currentUser = getCurrentUser();
        if (!currentUser || currentUser.role !== 'admin') {
            if (productList) {
                productList.innerHTML = '<div class="empty-state">Admin access required. Please sign in as an administrator.</div>';
            }
            if (form) {
                form.style.display = 'none';
            }
            return;
        }

        if (form) {
            form.addEventListener('submit', async (event) => {
                event.preventDefault();

                const imageFile = form.imageFile && form.imageFile.files ? form.imageFile.files[0] : null;
                let imageData = '';

                if (imageFile) {
                    imageData = await new Promise((resolve, reject) => {
                        const reader = new FileReader();
                        reader.onload = () => resolve(reader.result);
                        reader.onerror = () => reject(new Error('Image upload failed.'));
                        reader.readAsDataURL(imageFile);
                    });
                }

                const product = addProduct({
                    name: form.name.value,
                    price: form.price.value,
                    category: form.category.value,
                    image: imageData,
                    description: form.description.value
                });
                form.reset();
                if (productList) {
                    renderAdminProducts(productList);
                }
                alert(`Added new product: ${product.name}`);
            });
        }

        if (productList) {
            renderAdminProducts(productList);
        }
    }

    function renderAdminProducts(container) {
        const products = getProducts();
        container.innerHTML = products.map((product) => `
            <div class="admin-product-item">
                <strong>${product.name}</strong>
                <span>${product.category}</span>
                <span>${formatCurrency(product.price)}</span>
            </div>
        `).join('');
    }

    function handleCartPage() {
        const container = document.getElementById('cartContainer');
        const totalBox = document.getElementById('totalPrice');
        if (!container || !totalBox) return;

        const cart = getCart();
        container.innerHTML = '';

        if (!cart.length) {
            container.innerHTML = '<div class="empty-state">Your cart is empty. Browse products to fill it.</div>';
            totalBox.textContent = 'Total: ₹0';
            return;
        }

        let total = 0;
        cart.forEach((product, index) => {
            const price = Number(product.price) || 0;
            total += price;
            container.innerHTML += `
                <div class="product-card">
                    <h3>${product.name}</h3>
                    <p>${product.category}</p>
                    <p>${formatCurrency(price)}</p>
                    <button onclick="window.GadgetHub.removeCartItem(${index})">Remove</button>
                </div>
            `;
        });
        totalBox.textContent = `Total : ${formatCurrency(total)}`;
    }

    function handleCheckoutPage() {
        const form = document.getElementById('checkoutForm');
        if (!form) return;

        const currentUser = getCurrentUser();
        if (currentUser) {
            form.name.value = currentUser.name || '';
            form.email.value = currentUser.email || '';
        }

        form.addEventListener('submit', (event) => {
            event.preventDefault();
            const cart = getCart();
            if (!cart.length) {
                alert('Cart is empty.');
                return;
            }

            const order = createOrder({
                userId: currentUser ? currentUser.id : null,
                userName: form.name.value.trim(),
                email: form.email.value.trim(),
                phone: form.phone.value.trim(),
                address: `${form.address.value.trim()}, ${form.city.value.trim()} - ${form.pincode.value.trim()}`,
                paymentMethod: form.paymentMethod.value,
                products: cart
            });

            alert(`Order placed successfully. Your order ID is ${order.id}`);
            window.location.href = 'receipt.html';
        });
    }

    function handleReceiptPage() {
        const order = getLatestOrder();
        const container = document.getElementById('receipt');
        if (!order || !container) return;

        container.innerHTML = `
            <div class="receipt-shell">
                <h2>Order Confirmed</h2>
                <p>Your order has been received and is now <strong>${order.status || 'Pending'}</strong>.</p>
                <p><strong>Order ID:</strong> ${order.id}</p>
                <p><strong>Customer:</strong> ${order.userName || 'Guest'}</p>
                <p><strong>Shipping Address:</strong> ${order.address || 'Not provided'}</p>
                <p><strong>Total:</strong> ${formatCurrency(order.total || 0)}</p>
                <a href="orders.html" class="button-link">Track My Order</a>
            </div>
        `;
    }

    function handleDetailsPage() {
        const productId = getSelectedProductId();
        if (!productId) return;

        const product = getProducts().find((entry) => Number(entry.id) === Number(productId));
        if (!product) {
            window.location.href = 'products.html';
            return;
        }

        const nameNode = document.getElementById('productName');
        const priceNode = document.getElementById('productPrice');
        const categoryNode = document.getElementById('productCategory');
        const imageNode = document.getElementById('productImage');

        if (nameNode) nameNode.innerText = product.name;
        if (priceNode) priceNode.innerText = formatCurrency(product.price);
        if (categoryNode) categoryNode.innerText = product.category;
        if (imageNode) imageNode.src = product.image || 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80';

        const wishlistBtn = document.getElementById('wishlistBtn');
        const cartBtn = document.getElementById('cartBtn');

        if (wishlistBtn) {
            wishlistBtn.addEventListener('click', () => {
                const wishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
                const exists = wishlist.some((item) => Number(item.id) === Number(product.id));
                if (!exists) {
                    wishlist.push(product);
                    localStorage.setItem('wishlist', JSON.stringify(wishlist));
                }
                alert('Added To Wishlist ❤️');
            });
        }

        if (cartBtn) {
            cartBtn.addEventListener('click', () => {
                addToCart(product.id);
            });
        }
    }

    function initialize() {
        ensureStorageReady();
        injectNavigation();
        renderAuthState();
        initTheme();
        handleHomePage();
        handleProductsPage();
        handleAuthPage();
        handleOrdersPage();
        handleAdminPage();
        handleCartPage();
        handleCheckoutPage();
        handleReceiptPage();
        handleDetailsPage();
    }

    window.GadgetHub = {
        getProducts,
        saveProducts,
        getUsers,
        saveUsers,
        getCart,
        saveCart,
        getOrders,
        saveOrders,
        getCurrentUser,
        setCurrentUser,
        registerUser,
        loginUser,
        logoutUser,
        addProduct,
        createOrder,
        updateOrderStatus,
        viewDetails,
        addToCart,
        removeCartItem,
        displayProducts,
        filterAndDisplay,
        getLatestOrder,
        setLatestOrder,
        formatCurrency,
        initialize,
        handleOrdersPage,
        handleAdminPage,
        handleCartPage,
        handleCheckoutPage,
        handleReceiptPage,
        handleDetailsPage,
        handleAuthPage,
        handleProductsPage
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }
})();
const categoryFilter = localStorage.getItem('categoryFilter');
if(categoryFilter){
	if(categorySelect){
		categorySelect.value = categoryFilter;
	}
	filterAndDisplay();
	localStorage.removeItem('categoryFilter');
}