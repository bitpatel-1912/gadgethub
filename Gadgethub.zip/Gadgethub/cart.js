function displayCart() {
    if (window.GadgetHub && window.GadgetHub.handleCartPage) {
        window.GadgetHub.handleCartPage();
        return;
    }

    window.addEventListener('DOMContentLoaded', () => {
        if (window.GadgetHub && window.GadgetHub.handleCartPage) {
            window.GadgetHub.handleCartPage();
        }
    });
}

function removeItem(index) {
    if (!window.GadgetHub || !window.GadgetHub.removeCartItem) {
        return [];
    }

    const cart = window.GadgetHub.removeCartItem(index);
    if (window.GadgetHub.handleCartPage) {
        window.GadgetHub.handleCartPage();
    }
    return cart;
}

function checkout() {
    if (!window.GadgetHub || !window.GadgetHub.getCart) {
        return;
    }

    const cart = window.GadgetHub.getCart();
    if (!cart.length) {
        alert('Cart is empty!');
        return;
    }
    window.location.href = 'checkout.html';
}

displayCart();